export const GET_PHOTOS = "GET_PHOTOS"
export const GET_SEARCHED_TAG = "GET_SEARCHED_TAG";
export const IS_LOADING = "IS_LOADING";
export const ERROR = "ERROR";