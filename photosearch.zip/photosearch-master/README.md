# PHOTOSEARCH powered by flickr

In this project we use a Flickr API to get images about the tag you enter in the input field, using ReactJS, context and hooks

## General Information

We can select a enter a tag or click on the tags showed in the images and get more images acoording to the tag selected

## Setup

To test this app, you need to follow this steps:

1. Clone the repository
2. Go to the directory and install all dependencies with: npm install.
3. Now, you can type on the terminal: npm start.
4. The project will run in http://localhost:3000
