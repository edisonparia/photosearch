import { createContext } from "react";

const PhotoContext = createContext();

export default PhotoContext;
